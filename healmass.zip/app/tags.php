<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tags extends Model
{
    //
}
