<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use Redirect;
use Session;
use App\Product;
use DB;

class ProductsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::all();
        return view('administrator.products.index')->with('products',$products);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('administrator.products.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $rules = [
            'product_name'=> 'required',
            'regularPrice'=> 'required',
            'discountPrice'=> 'required',
            'quantity'=> 'required',
            'description'=> 'required',
            'image1'=> 'required|nullable|max:1999',
            'image2'=> 'nullable|max:1999',
            'image1'=> 'nullable|max:1999',
            'image1'=> 'nullable|max:1999',
            'tag'=> 'required'
        ];

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $tag = $request->input('tag');
            return redirect()->back()->withInput()->withErrors($validator);
        }else{
        $regular_price = $request->input('regularPrice');
        $discount_price = $request->input('discountPrice');
        // is discount<regular?
        if ($discount_price >= $regular_price) {
           return redirect()->back()->withInput()->with('error','ERROR: Discount price can not be greater than or equal to regular price');
        }else {

            try {
                $product = new Product;
                $product->product_name = $request->input('product_name');
                $product->regular_price = $request->input('regularPrice');
                $product->discount_price = $request->input('discountPrice');
                $product->product_status_id = $request->input('status');
                $product->description = $request->input('description');
                $product->quantity = $request->input('quantity');
                $product->save();
                return redirect('/administrator/products')->with('success','New product created');
            } catch (\Throwable $th) {
                $error =  Session::flash('error', 'Sorry, operation could not be completed.'.$th->getMessage());
                return redirect()->back()->with($error);
            }
           

        }
    }

        // return $discount_price;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
