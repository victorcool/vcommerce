 <!-- Input addon -->
 <div class="box box-success">
           
    <div class="box-body">          
            <div class="box-body">
              <div class="row">
                <?php echo $__env->make('administrator/assets.inc.forms.imageUploadBox', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              </div>
                <div class="row">
                  <div class="col-md-6">
                      <div class="form-group">
                          <label for="product_name">Product Name</label>
                          <input type="text" value="<?php echo e(old('product_name')); ?>" name="product_name" class="form-control" id="Title" placeholder="Product name">
                        </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label for="status">Product Status</label>
                          <select class="form-control" name="status" id="Status">
                            <option value="1">Active</option>
                            <option value="2">inactive</option>
                          </select>
                        </div>
                  </div>

                  <div class="col-md-3">
                      <div class="form-group">
                          <label for="regularprice">Regular price</label>
                          <input type="number" value="<?php echo e(old('regularPrice')); ?>" name="regularPrice" class="form-control" id="rprice" placeholder="Regular price">
                        </div>
                  </div>
                  <div class="col-md-3">
                      <div class="form-group">
                          <label for="discountPrice">Discount price</label>
                          <input type="number" value="<?php echo e(old('discountPrice')); ?>" name="discountPrice" class="form-control" id="dprice" placeholder="Discount price">
                        </div>
                  </div>
                  <div class="col-md-3">
                      <div class="form-group <?php echo e(($errors->has('quantity')) ? 'has-error' : ''); ?>">
                          <label for="qauntity">Quantity</label>
                      <input type="number" value="<?php echo e(old('quantity')); ?>" name="quantity" class="form-control" id="Quantity" placeholder="Quantity">
                        </div>
                  </div>
                  <div class="col-md-3">
                    <div class="form-group <?php echo e(($errors->has('tag')) ? 'has-error' : ''); ?>">
                      <label for="tag">Tag</label>
                      <select class="form-control select2" name="tag[]" multiple="multiple" data-placeholder="Select a Tag"
                              style="width: 100%;">
                        <option>healmass</option>
                        <option>parent</option>
                        <option>banner</option>
                        <option>slider</option>
                        <option>Tennessee</option>
                        <option>Texas</option>
                        <option>Washington</option>
                      </select>
                    </div>
                  </div>

              <div class="col-md-12">
                  <div class="form-group">
                      <label for="description">Description</label>
                      <textarea name="description" id="article-ckeditor" class="form-control"></textarea>
                    </div>
              </div>            
              
            </div>
            <!-- /.box-body -->

            <div class="box-footer">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
             
    </div>
  </div>
    <!-- /.box-body -->
  </div>
  <!-- /.box -->