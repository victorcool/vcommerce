<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
<?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
<!-- header -->
<?php echo $__env->yieldContent('content'); ?>
<!-- //banner -->

<!-- footer -->
<?php echo $__env->make('temp.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- //footer -->
<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	<!-- js -->
	<?php echo $__env->make('includes.jslinks', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->yieldContent('jslink'); ?>

</body>
</html>