<div class="banner-top" id="home">
	
	<?php echo $__env->yieldContent('topNavbar'); ?>



<?php echo $__env->yieldContent('mainNavbar'); ?>
<!-- //header -->
<!-- banner -->
<?php echo $__env->yieldContent('slider'); ?>
</div>