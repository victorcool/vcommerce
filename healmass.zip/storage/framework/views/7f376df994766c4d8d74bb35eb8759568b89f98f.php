<?php $__env->startSection('content'); ?>
<?php $__env->startSection('boxtitle'); ?>
    <a href="<?php echo e(url('administrator/posts/create')); ?>" class="btn btn-default"><i class="fa fa-plus"></i> Create Post</a>
<?php $__env->stopSection(); ?>
<?php if(count($posts) > 0): ?>
<ul class="list-group">
  <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="well">
      <h4><a href="posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h4>
      <span>Written on <?php echo e($post->created_at); ?></span>
      
      </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php echo e($posts->links()); ?>

</ul> 
<?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>