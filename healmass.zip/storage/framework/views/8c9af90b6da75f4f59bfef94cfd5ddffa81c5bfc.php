<div class="nav-top">
	<nav class="navbar navbar-default">
	
	<div class="navbar-header nav_2">
		<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		

	</div> 
	<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
		<ul class="nav navbar-nav ">
			<li class=" active"><a href="index.html" class="hyper "><span>Home</span></a></li>	
			<?php if(count($categories) > 0): ?>
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if(! $category->subcategories->isEmpty()): ?>
					<li class="dropdown ">
							<a href="#" class="dropdown-toggle  hyper" data-toggle="dropdown" ><span><?php echo e($category->category_name); ?><b class="caret"></b></span></a>
							<ul class="dropdown-menu multi">
								<div class="row">
									<?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcateg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="col-sm-3">
										<ul class="multi-column-dropdown">				
											<li><a href="market/showroom/<?php echo e($subcateg->id); ?>"><i class="fa fa-angle-right" aria-hidden="true"></i><?php echo e($subcateg->subcateg_name); ?></a></li>												
										</ul>										
										</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>								
									<div class="col-sm-3 w3l">
										<a href="kitchen.html"><img src="images/me.png" class="img-responsive" alt=""></a>
									</div>
									<div class="clearfix"></div>
								</div>	
							</ul>
						</li>
					<?php else: ?>
						<li><a href="#" class="hyper "><span><?php echo e($category->category_name); ?></span></a></li>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
			
			
		</ul>
	</div>
	</nav>
	 <div class="cart" >
	
		<span class="fa fa-shopping-cart my-cart-icon"><span class="badge badge-notify my-cart-badge"></span></span>
	</div>
	<div class="clearfix"></div>
</div>