<!-- Input addon -->
<div class="box box-success">
    <div class="box-body">  
		<div class="box-body">
				<div class="form-group <?php echo e(($errors->has('postTitle')) ? 'has-error' : ''); ?>">
					<label for="title">Email address</label>
					<input type="text" name="postTitle" class="form-control" id="Title" placeholder="Enter email">
					<?php if($errors->has('postTitle')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('postTitle')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
				<div class="form-group <?php echo e(($errors->has('postBody')) ? 'has-error' : ''); ?>">
					<label for="postBody">Password</label>
					<textarea name="postBody" id="article-ckeditor" class="form-control"></textarea>
					<?php if($errors->has('postBody')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('postBody')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
				<!-- /.box-body -->
				<div class="box-footer">
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
		</div>
    </div>
    <!-- /.box-body -->
</div>
<!-- /.box -->