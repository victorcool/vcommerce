<?php $__env->startSection('content'); ?>
<?php $__env->startSection('boxtitle'); ?>
    <?php echo e('Edit Post'); ?>

    <?php $__env->stopSection(); ?>

<div class="row">
    <div class="col-md-12">       
        <?php echo Form::open(['action' => ['admin\CategoriesController@update', $categoryToEdit->id], 'method' => 'POST']); ?>

        <?php echo e(Form::hidden('_method','PUT')); ?>

        <?php echo $__env->make('administrator.assets.inc.forms.editCategoryForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo Form::close(); ?>

    </div>
</div>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>