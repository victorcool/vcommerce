
<div class="copy-right wow fadeInLeft animated" data-wow-delay=".5s">
	<div class="container">
			<p> &copy; 2017-<?php echo e(date('Y')); ?> <?php echo e(config('app.name','Healmass')); ?> . All Rights Reserved | Powered by  <a href="http://allforteck.com/"> allforteck</a></p>
	</div>
</div>