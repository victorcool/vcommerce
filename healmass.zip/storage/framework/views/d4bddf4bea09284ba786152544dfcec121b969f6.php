<?php $__env->startSection('content'); ?>
<?php $__env->startSection('boxtitle'); ?>
    <?php echo e('Create Products'); ?>

    <?php $__env->stopSection(); ?>

<div class="row">
    <div class="col-md-12">       
        <?php echo Form::open(['action' => 'admin\ProductsController@store', 'method' => 'POST','enctype' => 'multipart/form-data']); ?>

        <?php echo $__env->make('administrator.assets.inc.forms.createProductForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo Form::close(); ?>

    </div>
</div>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>