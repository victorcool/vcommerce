<?php $__env->startSection('content'); ?>

<?php $__env->startSection('boxtitle'); ?>
    <a href="<?php echo e(url('administrator/subcateg/create')); ?>" class="btn btn-default"><i class="fa fa-plus"></i> Add subCategory</a>
<?php $__env->stopSection(); ?>

<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    
<!-- timeline item -->
<?php if(! $category->subcategories->isEmpty()): ?>
<ul class="timeline">
<!-- timeline time label -->
    <li class="time-label">
            <span class="bg-green">
                <?php echo e($category->category_name); ?>

            </span>
        </li>
        <!-- /.timeline-label -->
            <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcateg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                    <!-- timeline icon -->
                    <i class="fa fa-long-arrow-right bg-aqua"></i>
                    <div class="timeline-item">
                        <span class="time"><a href="subcateg/<?php echo e($subcateg->id); ?>/edit"><i class="fa fa-pencil"></i> edit</a></span>
                        <span class="time">
                                <?php echo Form::open(['action' => ['admin\subCategsController@destroy', $subcateg->id], 'method' => 'POST']); ?>

                                <?php echo e(Form::hidden('_method','DELETE')); ?>

                                <?php echo e(Form::submit('remove',['class' => 'btn btn-default btn-xs'])); ?>

                                <?php echo Form::close(); ?>

                        </span>            
                    <h3 class="timeline-header"><a href="<?php echo e($subcateg->id); ?>"><?php echo e($subcateg->subcateg_name); ?></a></h3>
            
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
        <?php endif; ?>
        
        <!-- END timeline item -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    
        
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>