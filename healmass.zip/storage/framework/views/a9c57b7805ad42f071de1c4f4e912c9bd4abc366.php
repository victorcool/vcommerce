 <!-- TABLE: LATEST ORDERS -->
 <div class="box box-info">
    <div class="box-header with-border">
      <h3 class="box-title">Products Categories</h3>      
    </div>
    <!-- /.box-header -->
    <div class="box-body">
      <div class="table-responsive">
        <table class="table no-margin">
          <thead>
          <tr>
            <th>CategID</th>
            <th>Category name</th>
            <th>Date added</th>
            <th>More..</th>
          </tr>
          </thead>
          <tbody>
            <?php $i = 0;?>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e('#'.++$i); ?></td>
                    <td><?php echo e($category->category_name); ?></td>
                    <td><?php echo e($category->created_at); ?></td>
                    <td>
                    <a href="categories/<?php echo e($category->id); ?>/edit" class="label label-success"><i class="fa fa-pencil"></i> Edit</span></a>
                        <a href="#" class="label label-danger"><i class="fa fa-remove"></i> remove</span></a>
                    </td>                  
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
              <?php echo e($categories->links()); ?>        
          </tbody>
        </table>
      </div>
      <!-- /.table-responsive -->
    </div>
    <!-- /.box-body -->
    
    <!-- /.box-footer -->
  </div>
  <!-- /.box -->