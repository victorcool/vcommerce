<?php $__env->startSection('content'); ?>

<?php $__env->startSection('boxtitle'); ?>
    <a href="<?php echo e(url('administrator/categories/create')); ?>" class="btn btn-sm btn-info btn-flat"><i class="fa fa-plus"></i> Add Category</a>
<?php $__env->stopSection(); ?>

<?php if(count($categories)>0): ?>
    <?php echo $__env->make('administrator.assets.inc.tables.categ_list_tbl', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
    <?php else: ?> 
<h4>No Category created</h4>

<?php endif; ?>


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>