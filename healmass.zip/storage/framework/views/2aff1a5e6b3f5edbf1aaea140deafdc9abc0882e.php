<div class="wrap-custom-file col-md-3 col-xs-6 <?php echo e(($errors->has('image1')) ? 'has-error' : ''); ?>">
        <input type="file" name="image1" id="image1" accept=".gif, .jpg, .png" />
        <label  for="image1">
          <span>Image One</span>
          <i class="fa fa-plus-circle"></i>
        </label>
      </div>
    
    <div class="wrap-custom-file col-md-3 col-xs-6">
        <input type="file" name="image2" id="image2" accept=".gif, .jpg, .png" />
        <label  for="image2">
          <span>Image Two</span>
          <i class="fa fa-plus-circle"></i>
        </label>
      </div>
    
      <div class="wrap-custom-file col-md-3 col-xs-6">
        <input type="file" name="image3" id="image3" accept=".gif, .jpg, .png" />
        <label  for="image3">
          <span>Image Three</span>
          <i class="fa fa-plus-circle"></i>
        </label>
      </div>
    
       <div class="wrap-custom-file col-md-3 col-xs-6">
        <input type="file" name="image4" id="image4" accept=".gif, .jpg, .png" />
        <label  for="image4">
          <span>Image Four</span>
          <i class="fa fa-plus-circle"></i>
        </label>
      </div>
    <!-- End Page Wrap -->