<title><?php echo $__env->yieldContent('title'); ?></title>
	<!--/metadata -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="UTF-8">
<meta name="keywords" content="Best Look Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smart phone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="<?php echo e(asset('mainSite/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo e(asset('mainSite/css/JiSlider.css')); ?>" rel="stylesheet"> 
<link href="<?php echo e(asset('mainSite/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome-icons -->
<link href="<?php echo e(asset('mainSite/css/font-awesome.css')); ?>" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>