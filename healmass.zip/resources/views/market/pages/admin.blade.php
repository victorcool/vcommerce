@extends('layouts.master')

@section('content') 
@include('forms.login-form')  
@endsection