@extends('layouts.app')

@section('content') 
@include('forms.registration-form')  
@endsection