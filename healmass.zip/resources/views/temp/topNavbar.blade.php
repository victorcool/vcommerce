<div class="header">
	<div class="container">
			<div class="header-left">
				<div class="agileinfo-phone">
					<p><i class="fa fa-volume-control-phone" aria-hidden="true"></i> +1 234 567 8901</p>
				</div>
				
				<div class="search-grid">
					<form action="#" method="post">
						<input type="text" name="subscribe" placeholder="Search" class="big-dog" name="Subscribe" required="">
						<button class="btn1"><i class="fa fa-search" aria-hidden="true"></i></button>
					</form>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>	
		</div> 