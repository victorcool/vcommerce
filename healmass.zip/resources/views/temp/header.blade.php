<div class="banner-top" id="home">
	{{-- top navbar--}}
	@yield('topNavbar')
{{-- //top --}}

{{-- header --}}
@yield('mainNavbar')
<!-- //header -->
<!-- banner -->
@yield('slider')
</div>