<div class="testimonials" id="testimonials">
    <div class="container">
        <div class="w3_agile_team_grid">
            
            <div class="w3-heading-all">
                <h3>What Our <span>Clients</span> Says</h3>
                
            </div>
            <div class="clearfix"> </div>
        </div>
        <div class="w3ls_testimonials_grids">
             <section class="center slider">
                    <div class="agileits_testimonial_grid">
                        <div class="w3l_testimonial_grid">
                            <p>In eu auctor felis, id eleifend dolor. Integer bibendum dictum erat, 
                                non laoreet dolor.</p>
                            <h4>Rosy Crisp</h4>
                            <h5>Student</h5>
                            <div class="w3l_testimonial_grid_pos">
                                <img src="images/t1.jpg" alt=" " class="img-responsive" />
                            </div>
                        </div>
                    </div>
                    <div class="agileits_testimonial_grid">
                        <div class="w3l_testimonial_grid">
                            <p>In eu auctor felis, id eleifend dolor. Integer bibendum dictum erat, 
                                non laoreet dolor.</p>
                            <h4>Laura Paul</h4>
                            <h5>Student</h5>
                            <div class="w3l_testimonial_grid_pos">
                                <img src="images/t2.jpg" alt=" " class="img-responsive" />
                            </div>
                        </div>
                    </div>
                    <div class="agileits_testimonial_grid">
                        <div class="w3l_testimonial_grid">
                            <p>In eu auctor felis, id eleifend dolor. Integer bibendum dictum erat, 
                                non laoreet dolor.</p>
                            <h4>Michael Doe</h4>
                            <h5>Student</h5>
                            <div class="w3l_testimonial_grid_pos">
                                <img src="images/t3.jpg" alt=" " class="img-responsive" />
                            </div>
                        </div>
                    </div>
            </section>
        </div>
    </div>
</div>