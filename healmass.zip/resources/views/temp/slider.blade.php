<div class="banner-silder">
    <div id="JiSlider" class="jislider">
        <ul>
            <li>
                <div class="w3layouts-banner-top">

                        <div class="container">
                            <div class="agileits-banner-info">
                            
                                <h3>WE ARE PROFESSIONAL DESIGNERS </h3>
                                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.Sed blandit massa vel mauris sollicitudin dignissim.</p>
                                
                            </div>	
                        </div>
                    </div>
            </li>
            <li>
                    <div class="w3layouts-banner-top w3layouts-banner-top1">
                    <div class="container">
                            <div class="agileits-banner-info">
                             
                                <h3>WE ARE EXPERIENCED  DESIGNERS</h3>
                                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.Sed blandit massa vel mauris sollicitudin dignissim.</p>
                                
                            </div>	
                        </div>
                    </div>
            </li>
            <li>
                    <div class="w3layouts-banner-top w3layouts-banner-top2">
                        <div class="container">
                            <div class="agileits-banner-info">
                                
                                <h3>WE ARE QUALITY  DESIGNERS</h3>
                                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.Sed blandit massa vel mauris sollicitudin dignissim.</p>
                                
                            </div>
                            
                        </div>
                    </div>
                </li>
                <li>
                    <div class="w3layouts-banner-top w3layouts-banner-top3">
                        <div class="container">
                            <div class="agileits-banner-info">
                             
                                <h3>WE ARE FRIENDLY  DESIGNERS</h3>
                                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.Sed blandit massa vel mauris sollicitudin dignissim.</p>
                                
                            </div>
                            
                        </div>
                    </div>
                </li>
        </ul>
    </div>
  </div>